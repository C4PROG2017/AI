# Artificial Intelligence

This is the repository for the 2017 Artificial Intelligence Units. You will only be able to push files to your branch. If you are unable to push to the repository, check that you have been added to the organization. Be sure you are pushing files to correct folder.
